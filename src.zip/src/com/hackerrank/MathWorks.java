package com.hackerrank;

public class MathWorks {

    public static void main(String[] args) {

    }
}
