package com.hackerrank;

public class FeatureLabs {

    
}
