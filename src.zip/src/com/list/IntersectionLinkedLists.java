package com.list;

public class IntersectionLinkedLists {

    /*
    Static void(Node node1, Node node2){
        if(node1==null || node2==null){
            Return null;
        }
        Node a = node1;
        Node b = node2;
        while(a!=b){
            A = a == null ? node2 : a.next;
            B = b == null ? node1; b.next;
        }
        Return a;
        */





}
