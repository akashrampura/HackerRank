package com.strings;

public class Substring {

    public static void main(String[] args) {
        String s1 = "geeksforgeeks";
        String s2 = "for";

        System.out.println(s1.indexOf(s2));
    }
}
